package io.realword.model.entity;

public class ArticleEntity {
}
